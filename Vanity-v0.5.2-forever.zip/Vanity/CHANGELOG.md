# Vanity

## v0.5.2
- Fonts: the font pack now ships inside this add-on (Fonts folder), so the separate Look Fonts add-on is no longer needed, and there are about 60 more fonts to pick from under Look > Font.

## v0.5.1
- Error reporting improvements; /issues log.

## v0.5.0
- New: pose picker. A Pose button on the showcase window (and in photo mode) opens a menu of 22 poses and emotes: salute, wave, bow, cheer, applaud, laugh, cry, flex, shy, point, beg, kiss, roar, rude, chicken, dance, sit, sleep, kneel, plus stand, walk and run. One-shot emotes replay every few seconds until you pick another pose; sit, sleep, kneel and dance hold. Closing the window puts your character back to standing.

## v0.4.3
- Shared look: background color picker, 13 new backgrounds with brightness and grain, a gold trim option, and buttons and slots stay visible on a pure black panel.

## v0.4.0
- New: window customization. Alt-click the minimap button to restyle each window separately (or all together): background textures, colors with copy/paste, opacity sliders, border styles, fonts, scale and position lock. Over 50 fonts to pick from (install the LookFonts folder for the bundled ones; SharedMedia fonts show up too). Off until you tick "Use a custom look"; unticking restores the original. All of the add-on's options now live in that same window, on an Options tab, and the window itself wears the first window's look.

## v0.3.10
- The Vanity button on the character window is now off by default (existing installs are switched off once). Turn it back on in Settings; when on, shift-drag it to move it anywhere and the spot is remembered. Vanity is still on the minimap button, the addon list, and /vanity.

## v0.3.9
- Fix: item cards showed only their first line (the stat and enchant lines were cut off). Every line now shows, one per row.

## v0.3.8
- Item cards now match the tooltip layout: armor and stat lines (+Strength, +Stamina ...) beside each item, colored by the item's rarity, with enchants, equip/use effects and problems underneath. Slot spacing widened to fit.

## v0.3.7
- Item cards: every equipped item now shows its details permanently beside its slot - name in quality color, item level, main stats, enchant and any problems - no hovering needed. Works in the showcase and on the AFK screen. Turn off under Settings ("Item cards"). With cards on, the Attributes panel moves to the bottom left.

## v0.3.6
- AFK screen: item and buff tooltips now show (the game's tooltip was hidden with the interface; Vanity uses its own). Your active buffs appear bottom right with tooltips.
- Removed the "Everything enchanted and gemmed" line (missing enchants/gems still list and flag on the slots) and the "Print Screen is safe" line.
- Name at top left uses the game's full display name (including any surname/title).
- Nicer look: drifting gold embers and a soft plate behind the timer.

## v0.3.1
- New addon icon (gold V on a dark tile) for the AddOns list and the minimap button.
- Release packaging for GitHub, Wago and CurseForge.

## v0.3.0
- Polish pass: framed slots with quality-colored edges and the game's empty-slot icons, an item level badge on each item, hover highlight, a fancy name and item level font, a class-colored accent line under the header, an Attributes card for the stats, and a soft spotlight beam behind the model.
- AFK screen: cinematic black bars, a fade-in, a pulsing A F K title between gold rules, a big timer, clock and date, and an info line that rotates item level, durability and zone.

## v0.2.2
- The AFK screen keeps your showcase: equipped items with item levels, stats, item level and durability stay on screen alongside the timer and clock. Only the buttons and the game's own interface are hidden.
- Print Screen and modifier keys no longer end the AFK screen, so you can screenshot it.
- AFK and photo mode also switch off floating player names and nameplates (through the game's own settings, restored afterwards), and the "move or press a key" hint no longer overlaps the weapon slots.
- Fixed: a gear change while in photo mode brought the slots back.

## v0.2.1
- Item glows now wrap the whole slot (they were drawn at button size, so they looked tiny).
- AFK mode and photo mode hide the game interface (like Alt+Z) so only your character and the Vanity overlay show. The interface comes back when you leave, close the window, enter combat, or type `/vanity ui`. Setting: Game interface > Hide in AFK/photo, or Leave it on.
- The "The world" background now dims the interface behind the normal showcase instead of letting it clutter the view.

## v0.2.0
- **14 backgrounds**, picked from swatches: Midnight, Class color, Faction, Ember, Frost, Forest, Void, Gilded, Sunset, Slate, Pure black, Studio white, Green screen, and The world.
- **Settings panel** (`/vanity settings` or the Settings button): background, brightness, floor glow, darkened edges, camera framing (full body, waist up, bust, portrait), turntable and speed, stats panel, slot names, hints, character-window button.
- **AFK screen:** go AFK and Vanity takes over with your character slowly turning, a timer, a clock and your item level. It cycles poses (sit, wave, laugh, dance ...). Move or press a key to leave. `/vanity afk` previews it. Options for turning it off, turning off poses, and a 24-hour clock.

## v0.1.1
- New stage look: dark ceiling, a floor glow in your class color, darkened edges. "Class color" tints the whole stage.
- Enchant warnings only appear from level 40.

## v0.1.0
- First release: full-screen rotatable model, gear with item levels, missing enchant and gem warnings, durability, stats, photo studio, target viewer.
